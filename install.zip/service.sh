#!/system/bin/sh

$MODPATH/bin/frpc -c $MODPATH/etc/frpc.toml